# Exercice dirigé: Transition CSS

## Menu
Créer un menu conformément à la maquette fournie.
- couleur de fond du menu #DD5735
- couleur du texte des rubriques #fff

## Au survol des rubriques
- la couleur du texte passe progressivement à #333 (en 0.2s)
- la couleur de fond passe progressivement à #fc3 (en 1s)
- la rubrique est agrandie 1.5 fois (en 0.5s)

Un exemple est montré à la rubrique 4