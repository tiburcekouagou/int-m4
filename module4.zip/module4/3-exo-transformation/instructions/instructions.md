# Exercice dirigé: Animation CSS

## Rotate
Intégrer l'image de la flèche comme montré sur les maquettes.
- Par défaut celle-ci pointe à l'horizontal. 
- Au survol, elle pointe vers le haut. 
- Le changement se fait progressivement.

## Scale
Intégrer le picto de l'ordinateur fourni tel que sur la maquette. 
- Au survol, celui-ci se réduit en taille et laisse apparaître progressivement le texte "Projet".
