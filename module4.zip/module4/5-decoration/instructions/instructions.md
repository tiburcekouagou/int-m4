# Exercice dirigé: Décoration

## Dégradés

Découverte des fonctions linear-gradient(), repeating-linear-gradient(), radial-gradient() et des paramètres associés

## Ombre sur les boîtes

Découverte de la propriété box-shadow

## Ombre sur les textes

Découverte de la propriété text-shadow
