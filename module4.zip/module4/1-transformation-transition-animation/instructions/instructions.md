# Exercice dirigé: Transform, transition et animation

- Intégrer 7 DIV avec du lorem ipsum
- Appliquer à chaque DIV une valeur de transform pour les 5 premiers
- Pour le 6ème, ajouter le CSS pour qu'au survol de l'élément un zoom se fasse progressivement
- Pour le 7ème, créez une animation CSS pour qu'au clic sur le bouton "OK" l'élément apparaisse en même temps en zoom et en rotation
