# Exercice dirigé: Animation CSS

## Loader 1
Reproduire l'animation de loader conformément au fichier "loader-1.mp4" en CSS, à l'aide des propriétés d'animation et de transformation.

## Loader 2
Reproduire l'animation de loader conformément au fichier "loader-2.mp4" en CSS, à l'aide des propriétés d'animation et de transformation.

Les animations doivent se jouer en boucle.